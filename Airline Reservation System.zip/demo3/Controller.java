import javafx.event.ActionEvent;
public class Controller {
    public void up(ActionEvent e){
        System.out.println("UP");
    }
    public void up(ActionEvent e){
        System.out.println("DOWN");
    }
    public void up(ActionEvent e){
        System.out.println("LEFT");
    }
    public void up(ActionEvent e){
        System.out.println("RIGHT");
    }
}
